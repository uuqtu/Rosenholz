﻿using System;

namespace RomanNumerals
{
    public static class OutputDisplayer
    {
        public static void DisplayOutput(string output)
        {
            Console.WriteLine(output);
        }
    }
}
