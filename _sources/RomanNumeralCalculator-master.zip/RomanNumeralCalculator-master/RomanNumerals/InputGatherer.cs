﻿using System;

namespace RomanNumerals
{
    public static class InputGatherer
    {
        public static string GetInputFromUser()
        {
            return Console.ReadLine();
        }
    }
}
