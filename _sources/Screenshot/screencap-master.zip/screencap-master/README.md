# Screencap
[![Build status](https://ci.appveyor.com/api/projects/status/46praega0c6gkcec?svg=true)](https://ci.appveyor.com/project/DuncanLeo/screencap)  
This app brings over the macOS shortcut-based screenshots system to Windows.

## Capture Areas
- Fullscreen
- Region
- Window

## Save targets
- Desktop folder
- Clipboard (TODO!)

## Development
- Open the solution in Visual Studio 2017.
