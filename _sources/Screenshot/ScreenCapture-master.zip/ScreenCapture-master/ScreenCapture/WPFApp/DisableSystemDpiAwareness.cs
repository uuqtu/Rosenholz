using System.Windows.Media;

// Disable WPF's built-in scaling, we're doing it ourselves
[assembly:DisableDpiAwareness]