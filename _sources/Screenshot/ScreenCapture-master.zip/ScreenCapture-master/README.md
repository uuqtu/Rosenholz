# ScreenCapture
A Windows tool for taking screenshots.
