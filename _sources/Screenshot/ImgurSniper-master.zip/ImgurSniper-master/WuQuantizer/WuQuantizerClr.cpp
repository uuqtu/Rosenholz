#include "Quantizer.h"
using namespace System;

namespace WuQuantizer {
	public ref class WuQuantizerClr {
	public:
		static long Vol(box cube, long[][][] mmt) {

		}
	};
}