﻿namespace ImgurSniper.UI {
    internal class VersionInfoItem {
        public string Version { get; set; }
        public string Date { get; set; }
        public string Message { get; set; }
    }
}