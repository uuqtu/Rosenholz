﻿using System.Windows.Controls;

namespace ImgurSniper.UI.Pages {
    /// <summary>
    ///     Interaction logic for GeneralPage.xaml
    /// </summary>
    public partial class GeneralPage : Page {
        public GeneralPage() {
            InitializeComponent();
        }
    }
}