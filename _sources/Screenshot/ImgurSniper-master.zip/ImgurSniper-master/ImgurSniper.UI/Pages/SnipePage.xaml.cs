﻿using System.Windows.Controls;

namespace ImgurSniper.UI.Pages {
    /// <summary>
    ///     Interaction logic for SnipePage.xaml
    /// </summary>
    public partial class SnipePage : Page {
        public SnipePage() {
            InitializeComponent();
        }
    }
}