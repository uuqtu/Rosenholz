﻿using System.Windows.Controls;

namespace ImgurSniper.UI.Pages {
    /// <summary>
    ///     Interaction logic for TrayPage.xaml
    /// </summary>
    public partial class TrayPage : Page {
        public TrayPage() {
            InitializeComponent();
        }
    }
}