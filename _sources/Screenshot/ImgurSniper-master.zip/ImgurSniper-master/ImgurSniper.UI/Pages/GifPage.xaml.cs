﻿using System.Windows.Controls;

namespace ImgurSniper.UI.Pages {
    /// <summary>
    ///     Interaction logic for GifPage.xaml
    /// </summary>
    public partial class GifPage : Page {
        public GifPage() {
            InitializeComponent();
        }
    }
}