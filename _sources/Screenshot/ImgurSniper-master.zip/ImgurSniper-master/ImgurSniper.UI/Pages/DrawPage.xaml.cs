﻿using System.Windows.Controls;

namespace ImgurSniper.UI.Pages {
    /// <summary>
    ///     Interaction logic for DrawPage.xaml
    /// </summary>
    public partial class DrawPage : Page {
        public DrawPage() {
            InitializeComponent();
        }
    }
}