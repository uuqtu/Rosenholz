﻿using System.Windows.Controls;

namespace ImgurSniper.UI.Pages {
    /// <summary>
    ///     Interaction logic for RightClickPage.xaml
    /// </summary>
    public partial class RightClickPage : Page {
        public RightClickPage() {
            InitializeComponent();
        }
    }
}