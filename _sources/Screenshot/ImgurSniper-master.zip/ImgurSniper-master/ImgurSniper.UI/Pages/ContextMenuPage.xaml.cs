﻿using System.Windows.Controls;

namespace ImgurSniper.UI.Pages {
    /// <summary>
    ///     Interaction logic for ContextMenuPage.xaml
    /// </summary>
    public partial class ContextMenuPage : Page {
        public ContextMenuPage() {
            InitializeComponent();
        }
    }
}