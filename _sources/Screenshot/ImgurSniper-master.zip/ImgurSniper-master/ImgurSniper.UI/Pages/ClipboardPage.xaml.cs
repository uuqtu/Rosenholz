﻿using System.Windows.Controls;

namespace ImgurSniper.UI.Pages {
    /// <summary>
    ///     Interaction logic for ClipboardPage.xaml
    /// </summary>
    public partial class ClipboardPage : Page {
        public ClipboardPage() {
            InitializeComponent();
        }
    }
}