﻿namespace ImgurSniper.UI {
    /// <summary>
    ///     Interaction logic for Help.xaml
    /// </summary>
    public partial class Help  {
        public Help() {
            InitializeComponent();
        }
    }
}